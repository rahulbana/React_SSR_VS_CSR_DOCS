# React Server Side Rendering Boilerplate

## Installation


```
git clone https://github.com/rahulbana/React_SSR_Boilerplate
cd React_SSR_Boilerplate
npm install
npm run build
npm start
```
