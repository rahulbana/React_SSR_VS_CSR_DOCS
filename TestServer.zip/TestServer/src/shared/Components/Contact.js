import React from 'react';
import {Link} from 'react-router-dom';
import Nav from '../sharedComponents/./Nav'

class Contact extends React.Component {
	render(){
		return (
			<div>
				<Nav/>
				<p>Contact</p>
			</div>
		);
	}
}
export default Contact;
